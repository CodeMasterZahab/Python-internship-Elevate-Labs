# Flask Portfolio Mini App
This is a simple personal portfolio website built with Flask.

## Structure
- app.py — main Flask application
- templates/ — HTML templates (Jinja2)
- static/css/style.css — basic styles
- static/images/profile.png — profile image (copied from uploaded file)
- data/contacts.csv — saved contact form submissions
- requirements.txt — Python dependencies

## Quick start
1. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate   # mac/linux
   venv\Scripts\activate    # windows
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   python app.py
   ```
4. Open http://127.0.0.1:5000 in your browser.

## Note
The profile image was copied from the uploaded file and saved to `static/images/profile.png`.
