from flask import Flask, render_template, request, redirect, url_for, flash
import csv
import os

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET', 'dev-secret')  # set in env for production

CONTACTS_FILE = os.path.join(app.root_path, 'data', 'contacts.csv')
os.makedirs(os.path.join(app.root_path, 'data'), exist_ok=True)
if not os.path.exists(CONTACTS_FILE):
    with open(CONTACTS_FILE, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['name','email','message'])

@app.route('/')
def index():
    projects = [
        {
            'title': 'Calculator using Java (Web-based)',
            'desc': 'Developed a command-line calculator using Java, capable of performing basic arithmetic operations.',
            'link': 'https://github.com/CodeMasterZahab/Projects/blob/main/Calculator%20using%20Java'
        },
        {
            'title': 'Calculator using Kotlin (App-based)',
            'desc': 'Developed a basic calculator Android app using Kotlin in Android Studio.',
            'link': 'https://github.com/CodeMasterZahab/Projects/blob/main/Calculator%20using%20Kotlin'
        }
    ]
    return render_template('index.html', projects=projects)

@app.route('/projects')
def projects():
    projects = [
        {'title':'Project A','desc':'A short description of Project A','link':'#'},
        {'title':'Project B','desc':'A short description of Project B','link':'#'}
    ]
    return render_template('projects.html', projects=projects)

@app.route('/contact', methods=['GET','POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name','').strip()
        email = request.form.get('email','').strip()
        message = request.form.get('message','').strip()

        if not name or not email or not message:
            flash('Please fill all fields.', 'danger')
            return redirect(url_for('contact'))

        with open(CONTACTS_FILE, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([name, email, message])

        flash('Thanks! Your message has been received.', 'success')
        return redirect(url_for('contact'))

    return render_template('contact.html')


if __name__ == '__main__':
    app.run(debug=True)
