import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("linkedin_jobs.csv")

company_counts = df['Company'].value_counts().head(10)

plt.figure(figsize=(10,6))
company_counts.plot(kind='bar')
plt.title('Top 10 Companies by Number of Job Listings')
plt.xlabel('Company')
plt.ylabel('Number of Job Listings')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('top_companies.png')
plt.show()
    