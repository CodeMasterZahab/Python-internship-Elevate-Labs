from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import pandas as pd
from bs4 import BeautifulSoup

# ---------- CONFIG ----------

KEYWORD = "Python Developer"
LOCATION = "India"
# ----------------------------

# Start WebDriver
driver = webdriver.Chrome()
driver.get("https://www.linkedin.com/login")
time.sleep(2)

# -------- Login --------
driver.find_element(By.ID, "username").send_keys(EMAIL)
driver.find_element(By.ID, "password").send_keys(PASSWORD + Keys.RETURN)
time.sleep(5)



# -------- Direct Job Search (MOST STABLE METHOD) --------
search_url = (
    f"https://www.linkedin.com/jobs/search/?"
    f"keywords={KEYWORD.replace(' ', '%20')}&location={LOCATION}"
)

driver.get(search_url)
time.sleep(6)

# -------- Scroll to Load Jobs --------
for _ in range(4):
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(3)

# -------- Parse HTML --------
soup = BeautifulSoup(driver.page_source, "html.parser")

# Flexible selector (VERY IMPORTANT)
jobs = soup.select("div.job-card-container")

print("🔍 Total job cards found:", len(jobs))

data = []


for job in jobs:
    try:
        title = job.find("span", class_="job-card-list__title").text.strip()
        company = job.find(
            "span", class_="job-card-container__primary-description"
        ).text.strip()
        location = job.find(
            "span", class_="job-card-container__metadata-item"
        ).text.strip()

        job_link = "https://www.linkedin.com" + job.find(
            "a", class_="job-card-list__title"
        )["href"]

        data.append({
            "Title": title,
            "Company": company,
            "Location": location,
            "Link": job_link
        })
    except:
        pass

# -------- Save to CSV --------
print("📊 Total jobs scraped:", len(data))

if len(data) == 0:
    print("❌ No jobs scraped. CSV not created.")
else:
    df = pd.DataFrame(data)
    df.drop_duplicates(inplace=True)
    df.to_csv("linkedin_jobs.csv", index=False)
    print("✅ CSV created successfully")

driver.quit()

