from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
import time
import random
import pandas as pd
from bs4 import BeautifulSoup

# ---------- CONFIG ----------
EMAIL = "zahaby04@gmail.com"
PASSWORD = "zahab5253"
KEYWORD = "Python Developer"
LOCATION = "India"
# ----------------------------

# ---------- CHROME OPTIONS (STEALTH) ----------
options = Options()
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_argument("--start-maximized")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option("useAutomationExtension", False)

driver = webdriver.Chrome(options=options)

# ---------- LOGIN ----------
driver.get("https://www.linkedin.com/login")
time.sleep(random.uniform(2, 4))

driver.find_element(By.ID, "username").send_keys(EMAIL)
time.sleep(random.uniform(1, 2))

driver.find_element(By.ID, "password").send_keys(PASSWORD + Keys.RETURN)
time.sleep(random.uniform(5, 7))

# ---------- JOB SEARCH ----------
search_url = (
    f"https://www.linkedin.com/jobs/search/?"
    f"keywords={KEYWORD.replace(' ', '%20')}&location={LOCATION.replace(' ', '%20')}"
)

driver.get(search_url)
time.sleep(random.uniform(5, 7))

# ---------- SCROLL TO LOAD JOBS ----------
for _ in range(5):
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(random.uniform(2.5, 4.5))

# ---------- PARSE PAGE ----------
soup = BeautifulSoup(driver.page_source, "html.parser")

# More stable container
jobs = soup.select("li.jobs-search-results__list-item")

print("🔍 Total job cards found:", len(jobs))

data = []

for job in jobs:
    try:
        title_tag = job.select_one("a.job-card-list__title")
        company_tag = job.select_one(
            "span.job-card-container__primary-description"
        )
        location_tag = job.select_one(
            "li.job-card-container__metadata-item"
        )

        if not title_tag:
            continue

        title = title_tag.get_text(strip=True)
        company = company_tag.get_text(strip=True) if company_tag else "N/A"
        location = location_tag.get_text(strip=True) if location_tag else "N/A"

        job_link = "https://www.linkedin.com" + title_tag.get("href")

        data.append({
            "Title": title,
            "Company": company,
            "Location": location,
            "Link": job_link
        })

    except Exception:
        continue

# ---------- SAVE TO CSV ----------
print("📊 Total jobs scraped:", len(data))

if data:
    df = pd.DataFrame(data)
    df.drop_duplicates(inplace=True)
    df.to_csv("linkedin_jobs.csv", index=False)
    print("✅ CSV created: linkedin_jobs.csv")
else:
    print("❌ No jobs scraped. Try changing keyword/location.")

driver.quit()
