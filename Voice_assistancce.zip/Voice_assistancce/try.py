import speech_recognition as sr
import pyttsx3
import webbrowser
import datetime
import random

# ---------------- INITIAL SETUP ----------------
recognizer = sr.Recognizer()
engine = pyttsx3.init()
engine.setProperty("rate", 160)

# ---------------- DATA ----------------
JOKES = [
    "Why do programmers love dark mode? Because light attracts bugs.",
    "Why did the computer get cold? It forgot to close its Windows.",
    "Why was the math book sad? It had too many problems."
]

# ---------------- CORE FUNCTIONS ----------------
def speak(text):
    print("Assistant:", text)
    engine.say(text)
    engine.runAndWait()

def listen():
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.4)
        print("Listening...")
        audio = recognizer.listen(source)

    try:
        command = recognizer.recognize_google(audio)
        print("User:", command)
        return command.lower()
    except sr.UnknownValueError:
        return ""
    except sr.RequestError:
        speak("Speech service is unavailable.")
        return ""

# ---------------- INTENT FUNCTIONS ----------------
def open_google():
    speak("Opening Google")
    webbrowser.open("https://www.google.com")

def open_youtube():
    speak("Opening YouTube")
    webbrowser.open("https://www.youtube.com")

def tell_time():
    now = datetime.datetime.now()
    speak(f"The current time is {now.strftime('%I:%M %p')}")

def tell_joke():
    speak(random.choice(JOKES))
    if random.random() < 0.3:
        speak("Would you like to hear another joke?")
        response = listen()
        if "yes" in response:
            tell_joke()

def take_note():
    speak("What should I write?")
    note = listen()
    if note:
        with open("notes.txt", "a") as file:
            file.write(note + "\n")
        speak("Note saved successfully.")
    else:
        speak("I did not catch that.")

def exit_assistant():
    speak("Goodbye. Have a nice day!")
    exit()

# ---------------- INTENT MAPPING ----------------
INTENTS = {
    ("google", "search"): open_google,
    ("youtube", "video"): open_youtube,
    ("time", "clock"): tell_time,
    ("joke", "funny"): tell_joke,
    ("note", "write"): take_note,
    ("exit", "stop", "quit"): exit_assistant
}

# ---------------- MAIN ASSISTANT ----------------
def assistant():
    speak("Hello, I am your voice assistant. How can I help you?")

    while True:
        command = listen()

        if not command:
            continue

        handled = False

        for keywords, action in INTENTS.items():
            if any(word in command for word in keywords):
                action()
                handled = True
                break

        if not handled:
            speak("Sorry, I did not understand that command.")

# ---------------- RUN ----------------
assistant()
