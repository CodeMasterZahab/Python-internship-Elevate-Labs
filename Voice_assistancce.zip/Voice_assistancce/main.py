import speech_recognition as sr
import pyttsx3
import webbrowser
import datetime
import random

# Initialize recognizer and TTS engine
recognizer = sr.Recognizer()
engine = pyttsx3.init()
engine.setProperty('rate', 160)

# Jokes list
jokes = [
    "Why do programmers love dark mode? Because light attracts bugs.",
    "Why did the computer get cold? It forgot to close its Windows.",
    "Why was the math book sad? It had too many problems."
]

# Speak function
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Listen function
def listen():
    with sr.Microphone() as source:
        print("Listening...")
        audio = recognizer.listen(source)
        try:
            command = recognizer.recognize_google(audio)
            print("You said:", command)
            return command.lower()
        except sr.UnknownValueError:
            return ""

# Assistant logic
def assistant():
    speak("Hello, I am your assistant. How can I help you?")

    while True:
        command = listen()

        if "open google" in command:
            webbrowser.open("https://www.google.com")
            speak("Opening Google")

        elif "open youtube" in command:
            webbrowser.open("https://www.youtube.com")
            speak("Opening YouTube")

        elif "time" in command or "current time" in command:
            current_time = datetime.datetime.now().strftime("%I:%M %p")
            speak(f"The current time is {current_time}")    

        elif "joke" in command:
            speak(random.choice(jokes))

        elif "note" in command:
            speak("What should I write?")
            note = listen()
            with open("notes.txt", "a") as f:
                f.write(note + "\n")
            speak("Note saved")

        elif "exit" in command or "stop" in command:
            speak("Goodbye!")
            break

# Run assistant
assistant()
